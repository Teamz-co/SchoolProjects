import flet as ft 
import random
def main(page: ft.Page):
    options_list = ['Rock', 'Paper', 'Scissors']
    
    
    ###Functions###
    def rock(e):
        determine_winner(rock_button.data)
        player_text.value = "Player chose Rock"
        page.update()
    def paper(e):
        determine_winner(paper_button.data)
        player_text.value = "Player chose Paper"
        page.update()
    def scissors(e):
        determine_winner(scissors_button.data)
        player_text.value = "Player chose Scissors"
        page.update()
    def reset(e):
        player_text.value = "Player"
        computer_text.value = "Computer"
        output_text.value = ""
        page.update()
    
    def determine_winner(player_choice):
        comp_option = random.choice(options_list)
        computer_text.value = f"Computer chose {comp_option}"
        if player_choice == comp_option:
            output_text.value = "Its a tie!"
            computer_text.value = f'Computer chose {comp_option}'
            output_text.color = 'blue'
        elif (player_choice == 'Paper' and comp_option == 'Scissors') or (player_choice == 'Rock' and comp_option == 'Paper') or (player_choice == 'Scissors' and comp_option == 'Rock'):
            output_text.value = 'Computer Wins!'
            computer_text.value = f"Computer chose {comp_option}"
            output_text.color = 'red'
        else:
            output_text.value = 'Player Wins!'
            computer_text.value = f"Computer chose {comp_option}"
            output_text.color = 'green'
        
        page.update()
            
        
        
    
    
    ######## page setup ########
    page.title="Rock Paper Scissors"
    page.window.width=480
    page.window.height=800
    page.theme_mode="light"
    page.window.center()
    page.vertical_alignment=ft.MainAxisAlignment.SPACE_EVENLY
    page.horizontal_alignment=ft.CrossAxisAlignment.CENTER

    ######## header ########
    header_text = ft.Text(
        "Rock Paper Scissors",
        color="BLUE",
        size=30
    )
    
    ###Player, VS, Computer text####
    player_text = ft.Text(
        "Player", color = 'blue', size = 30
    )
    versus_text = ft.Text(
        "VS", color = 'blue', size = 30
    )
    computer_text = ft.Text(
        "Computer", color = 'blue', size = 30
    )
    

    ###Image Buttons###
    rock_img = ft.Image(
       src = "C:\\Users\Tmela\CS120\Projects\Project_2\Images\\rock.png",
       tooltip = 'rock'
    )
    paper_img = ft.Image(
       src = "C:\\Users\Tmela\CS120\Projects\Project_2\Images\paper.png",
       tooltip = 'paper'
    )
    scissors_img = ft.Image(
       src = "C:\\Users\Tmela\CS120\Projects\Project_2\Images\scissors.png",
       tooltip = 'scissors'
    )
    




#### INPUT BUTTONS ###
    rock_button = ft.ElevatedButton(
       width = 96,
       height = 96,
       on_click = rock,
       content = ft.Row(
           [rock_img],
           alignment = ft.MainAxisAlignment.SPACE_AROUND
       ),
       data = 'Rock'
    )
    paper_button = ft.ElevatedButton(
       width = 96,
       height = 96,
       on_click = paper,
       content = ft.Row(
           [paper_img],
           alignment = ft.MainAxisAlignment.SPACE_AROUND
       ),
       data = 'Paper'
    )
    scissors_button = ft.ElevatedButton(
       width = 96,
       height = 96,
       on_click = scissors,
       content = ft.Row(
           [scissors_img],
           alignment = ft.MainAxisAlignment.SPACE_AROUND
       ),
       data = 'Scissors'
    )
    button_row = ft.Row(
        spacing=50,
        controls=[rock_button, paper_button, scissors_button],
        alignment=ft.MainAxisAlignment.CENTER
    )
    reset_button = ft.ElevatedButton(
        text = 'reset',
        on_click = reset
    )




######## output ########
    output_text = ft.Text(size = 30)

    
    
    page.add(
        header_text,
        player_text,
        versus_text,
        computer_text,
        button_row,
        output_text,
        reset_button,
    )
    
ft.app(main)
""" Rock paper scissors icons created by iconading from flaitcon.com

Rock paper scissors icons created by Cap Cool from flaitcon.com

Fist icons created by Freepik from flaitcon.com"""